'''
Created on 31 mar 2016


@author: TWINGSISTER (c) 2016
'''
bl_info = \
    {
        "name" : "Quadrics",
        "author" : "TWINGSISTER (https://sourceforge.net/u/twingsister/wiki/Home/)",
        "version" : (1, 0, 0),
        "blender" : (2, 5, 7),
        "location" : "View3D > Add > Mesh",
        "description" :
            "Generate a mesh for a quadric",
        "warning" : "Beta",
        "wiki_url" : "https://sourceforge.net/u/twingsister/wiki/Home/",
        "tracker_url" : "https://sourceforge.net/u/twingsister/tickets/",
        "category" : "Add Mesh"
    }
ThisPyName="Quadrics"
SverchokMenu="Generators" #  Nota that thre are sverchock cathegories that in menu.py are in two and then in the menu become one. 
# vedi juggle and join in menu
import QuadricsBody 
# from PyLink import register,unregister
class Quadrics(QuadricsBody.QuadricsBody):
    '''
    classdocs
    '''   
body=Quadrics() 
from RegistrableParametric import Rp
ob=Rp(body,ThisPyName,SverchokMenu)
def register():
    ob.registerOneParametric(ThisPyName,body)
def unregister():
    ob.unregisterOneParametric(ThisPyName)
